/**
 * Creates a House object and compares its attributes to that of the Criteria object
 * 
 * @author Kyle o'Grady 
 * @version October 10/2/22
 */

public class House {
    String address; // String that represents a houses address that is on the File
    int price;        // Integer that represents the price of a house that is on the file
    int area;        // Integer that represents the area of a house that is on the file
    int numBedrooms;// Integer that represents the Number of bedrooms of a house that is on the file
//------------------------------------------------------------------------------------------------------------
    /**
     * Constructor that creates a House object using the values on the file
     * 
     * @param address: string value
     * @param price: int value
     * @param area: int value
     * @param numBedrooms: int value
     */
    public House(String address, int price, int area, int numBedrooms){
        this.address = address;
        this.price = price;
        this.area = area;
        this.numBedrooms = numBedrooms;
    }
//------------------------------------------------------------------------------------------------------------
    //getter methods
    public String getAddress() {
        return address;
    }
    
    public int getPrice() {
        return price;
    }
    
    public int getArea() {
        return area;
    }
    
    public int getNumBedrooms() {
        return numBedrooms;
    }
//-------------------------------------------------------------------------------------------------
    /**
     * Compares a house object's values to a criteria's object's values 
     * to find any houses that have values that match the Critera's
     * 
     * @param c: Criteria object
     * @return: returns a boolean value of true if the house fits the criteria and false if it doesn't
     */
    public boolean satisfies(Critreia c) {
        int price = getPrice();
        int area  = getArea();
        int numBedrooms = getNumBedrooms();
        
        if (price >= c.getMinimunPrice() && price <= c.getMaximumPrice() && area >= c.getMinimumArea() && area <= c.getMaximumArea() && numBedrooms >= c.getMinimumNumberOfBedrooms() && numBedrooms <= c.getMaximumNumberOfBedrooms()) {
            return true;
        }else {
            return false;    
            }
        }
    /**
     * Creates a string describing a house object and it values so it can be printed
     */
    public String toString() {
        String toString = ("address: " + getAddress() + "\nprice: " + getPrice() + "\narea: " + getArea() + "\nbedrooms: " + getNumBedrooms());
        return toString;
    }
}