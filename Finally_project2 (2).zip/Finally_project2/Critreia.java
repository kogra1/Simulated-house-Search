/**
 * Creates a Criteria object that contains the values the customers looking for in the house
 * 
 * @author Kyle o'Grady 
 * @version October 10/2/22
 */

public class Critreia {
	int minimunPrice;			// The minimum price requested for a house
	int maximumPrice;			// The maximum price requested for a house
	int minimumArea;			// The minimum area requested for a house
	int maximumArea;			// The maximum area requested for a house
	int minimumNumberOfBedrooms;// The minimum number of bedrooms requested for a house
	int maximumNumberOfBedrooms;// The maximum number of bedrooms requested for a house
//------------------------------------------------------------------------------------------------------------
	/**
	 * Constructor for the criteria object that contains the requested house parameters
	 * 
	 * @param minimunPrice: int value
	 * @param maximumPrice: int value
	 * @param minimumArea: int value
	 * @param maximumArea: int value
	 * @param minimumNumberOfBedrooms: int value
	 * @param maximumNumberOfBedrooms: int value
	 */
	public Critreia(int minimunPrice, int maximumPrice, int minimumArea, int maximumArea, int minimumNumberOfBedrooms, int maximumNumberOfBedrooms) {
		this.minimunPrice = minimunPrice;
		this.maximumPrice = maximumPrice;
		this.minimumArea = minimumArea;
		this.maximumArea = maximumArea;
		this.minimumNumberOfBedrooms = minimumNumberOfBedrooms;
		this.maximumNumberOfBedrooms = maximumNumberOfBedrooms;
	}
	
//-------------------------------------------------------------------------------------------------
	//getter methods
	public int getMinimunPrice() {
		return minimunPrice;
	}
	public int getMaximumPrice() {
		return maximumPrice;
	}
	public int getMinimumArea() {
		return minimumArea;
	}
	public int getMaximumArea() {
		return maximumArea;
	}
	public int getMinimumNumberOfBedrooms() {
		return minimumNumberOfBedrooms;
	}
	public int getMaximumNumberOfBedrooms() {
		return maximumNumberOfBedrooms;
	}
}