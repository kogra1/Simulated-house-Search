 /**
 * Creates a HouseList object that adds house objects into the houseList array list,
 * also prints the a list of houses that fit the Criteria in the criteria object
 * and can't print houses in a concatenated string
 * 
 * @author Kyle o'Grady 
 * @version October 10/2/22
 */

import javafx.stage.Stage;
import javafx.scene.Scene;
import java.util.Properties;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
public class HouseList {
    ArrayList<House> houseList = new ArrayList<House>(); //creates an array list that will contain house objects
    
    // GUI Components
    private Stage          myStage;

    private View        HouseListView;
    private Scene        currentScene;

    private String loginErrorMessage = "";
    private String transactionErrorMessage = "";
//------------------------------------------------------------------------------------------------------------
/**
 * Reads a file with a list of houses and their attributes and then creates house objects
 * using those attributes and then adds those house objects to an array list called houseList
 * @param fileName: the file the method reads from
 */
    public HouseList(String fileName) {
        try {
            File obj1 = new File (fileName);
            Scanner reader = new Scanner(obj1);
            while (reader.hasNextLine()) {
                String s = reader.nextLine();
                String[] arrStr = s.split(" ");
                for (int i = 0; i < arrStr.length; i++) {

                String address = arrStr[0];
                i++;
                while(arrStr[i].isEmpty() ) {
                    i++;
                }
                int price = Integer.parseInt(arrStr[i]);
                i++;
                while(arrStr[i].isEmpty()) {
                    i++;
                }
                int area = Integer.parseInt(arrStr[i]);
                i++;
                while(arrStr[i].isEmpty()) {
                    i++;
                }
                int numBedrooms = Integer.parseInt(arrStr[i]);
                
                House newhouse = new House(address, price, area, numBedrooms);
                houseList.add(newhouse);
                }
            }
        
    }catch (IOException e) {
        System.out.println("File Not Found");
        System.exit(0);
    }
    
    myStage = MainStageContainer.getInstance();

        // Set up the initial view
    createAndShowListView();
}
//------------------------------------------------------------------------------------------------------------
    /**
     * prints out house objects and their attributes that fit the criteria in list format
     * 
     * @param c: Criteria object
     */
    public void printHouses(Critreia c) {
        boolean satisfy;
        for(int i = 0; i < houseList.size(); i++) {
            satisfy = houseList.get(i).satisfies(c);
            if (satisfy == true) {
                System.out.println(houseList.get(i));
            }
        }
        
    }
    /**
     * prints out house objects and their attributes that fit the criteria in a contacted string format
     * 
     * @param c: Criteria object
     */
    public String getHouses(Critreia c) {
        boolean satisfy;
        String x = "'";
        String s = " ";
        for(int i = 0; i < houseList.size(); i++) {
            satisfy = houseList.get(i).satisfies(c);
            if (satisfy == true) {
                 s += x + houseList.get(i);
            }
        }
        System.out.println(houseList.size());
        System.out.println(s);
        return s;
    }
    public void createAndShowListView()
        {

        // create our new view
        HouseListView = new HouseListView(this);
        currentScene = new Scene(HouseListView);

        // make the view visible by installing it into the stage
        swapToView(currentScene);

        }
        //---------------------------------------------------------------
    public void swapToView(Scene newScene)
    {
        if (newScene == null)
        {
            System.out.println
                    ("Invoice.swapToView(): Missing view for display");
            return;
        }

        // SWAP THE SCENE ON THE STAGE
        myStage.setScene(newScene);
        // RE-SIZE STAGE TO FIT NEW SCENE SIZE
        myStage.sizeToScene();
        //Place in center again
        WindowPosition.placeCenter(myStage);

    }
    public void reset()
    {
        createAndShowListView();
    }
}