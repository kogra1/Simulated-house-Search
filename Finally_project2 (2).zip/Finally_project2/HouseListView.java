// system imports
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import java.util.Properties;
import java.lang.Math;

import java.util.ArrayList;



public class HouseListView extends View
{

    // Model, which this View talks to
    private HouseList myModel;
    ArrayList<Integer> used = new ArrayList<Integer>();
    //HouseList boyHouseList = new HouseList("houses.txt");
    // GUI components
    //private ComboBox<String> salesTaxRate;
    //private ComboBox<String> numYears;
    private TextField MinimumPrice;
    private TextField MaximumPrice;
    private TextField MinimumArea;
    private TextField MaximumArea;
    private TextField MinimumBeds;
    private TextField MaximumBeds;
    
    private TextArea ChosenHome;
    private TextField totalPayment;
    private Button findDream;
    private Button notDream;
    private Button reset;

    // For showing error message
    private MessageView statusLog;

    // constructor for this class -- takes a model object
    //----------------------------------------------------------
    public HouseListView(HouseList houselist) // SAME PATTERN AS LoginView
    {
        super("HouseListView");
        myModel = houselist;

        // create a container for showing the contents
        VBox container = new VBox(10);
        container.setPadding(new Insets(15, 5, 5, 5));

        // create our GUI components, add them to this panel
        container.getChildren().add(createTitle());
        container.getChildren().add(createFormContent());

        // Error message area
        container.getChildren().add(createStatusLog("  "));

        getChildren().add(container);

        //populateFields();
    }


    // Create the title container
    //-------------------------------------------------------------
    private Node createTitle()
    {
        HBox container = new HBox();
        container.setAlignment(Pos.CENTER);

        Text titleText = new Text(" House Listing ");
        titleText.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        titleText.setWrappingWidth(300);
        titleText.setTextAlignment(TextAlignment.CENTER);
        titleText.setFill(Color.PURPLE);
        container.getChildren().add(titleText);

        return container;
    }


    // Create the main form content
    //-------------------------------------------------------------
    private VBox createFormContent()
    {
        VBox vbox = new VBox(10);

        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));
        
        Text MinimumPriceLabel = new Text("MinimumPrice ");
        MinimumPriceLabel.setWrappingWidth(150);
        MinimumPriceLabel.setTextAlignment(TextAlignment.RIGHT);
        grid.add(MinimumPriceLabel, 0, 0);

        MinimumPrice = new TextField();
        MinimumPrice.setPromptText("0");
        MinimumPrice.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent e) {
                processAction(e);
            }
        });
        grid.add(MinimumPrice, 1, 0);
        //---------------------------------------------------------------
        Text MaximumPriceLabel = new Text("MaximumPrice ");
        MaximumPriceLabel.setWrappingWidth(150);
        MaximumPriceLabel.setTextAlignment(TextAlignment.RIGHT);
        grid.add(MaximumPriceLabel, 0, 1);

        MaximumPrice = new TextField();
        MaximumPrice.setPromptText("500000");
        MinimumPrice.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                processAction(e);
            }
        });
        grid.add(MaximumPrice, 1, 1);

        //------------------------------------------------------------------

        Text MinimumAreaLabel = new Text("MinimumArea ");
        MinimumAreaLabel.setWrappingWidth(150);
        MinimumAreaLabel.setTextAlignment(TextAlignment.RIGHT);
        grid.add(MinimumAreaLabel, 0, 2);

        MinimumArea = new TextField();
        MinimumArea.setPromptText("0");
        MinimumArea.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                processAction(e);
            }
        });
        grid.add(MinimumArea, 1, 2);
        //------------------------------------------------------

        Text MaximumAreaLabel = new Text("MaximumArea ");
        MaximumAreaLabel.setWrappingWidth(150);
        MaximumAreaLabel.setTextAlignment(TextAlignment.RIGHT);
        grid.add(MaximumAreaLabel, 0, 3);

        MaximumArea = new TextField();
        MaximumArea.setPromptText("5000");
        MaximumArea.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                processAction(e);
            }
        });
        grid.add(MaximumArea, 1, 3);
        //------------------------------------------------------
        
        Text MinimumBedsLabel = new Text("MinimumBeds ");
        MinimumBedsLabel.setWrappingWidth(150);
        MinimumBedsLabel.setTextAlignment(TextAlignment.RIGHT);
        grid.add(MinimumBedsLabel, 0, 4);
        
        MinimumBeds = new TextField();
        MinimumBeds.setPromptText("0");
        MinimumBeds.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                processAction(e);
            }
        });
        grid.add(MinimumBeds, 1, 4);
        
        //------------------------------------------------------
        
        Text MaximumBedsLabel = new Text("MaximumBeds ");
        MaximumBedsLabel.setWrappingWidth(150);
        MaximumBedsLabel.setTextAlignment(TextAlignment.RIGHT);
        grid.add(MaximumBedsLabel, 0, 5);
        
        MaximumBeds = new TextField();
        MaximumBeds.setPromptText("10");
        MaximumBeds.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                processAction(e);
            }
        });
        grid.add(MaximumBeds, 1, 5);
        
        //-------------------------------------------------------
        /*
        Text salesTaxLabel = new Text
                ("salesTaxLabel ");
        salesTaxLabel.setWrappingWidth(150);
        salesTaxLabel.setTextAlignment(TextAlignment.RIGHT);
        grid.add(salesTaxLabel, 0, 7);

        salesTaxRate = new ComboBox<String>();
        salesTaxRate.setMinSize(100, 20);
        grid.add(salesTaxRate, 1, 7);
        */
        // ----------------------------------------------------------
        Text ChosenHomeLabel = new Text("Chosen Home ");
        ChosenHomeLabel.setWrappingWidth(150);
        ChosenHomeLabel.setTextAlignment(TextAlignment.RIGHT);
        grid.add(ChosenHomeLabel, 0, 6);

        ChosenHome = new TextArea();
        grid.add(ChosenHome, 1, 6);
        ChosenHome.setPrefHeight(80);
        ChosenHome.setPrefWidth(175);
        //ChosenHome.setDisable(true);
        ChosenHome.setEditable(false);
        //---------------------------------------------------------------------

        findDream = new Button("Find my dream house!");
        findDream.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent e) {
                clearErrorMessage();
                // do the calculation
                processAction(e);
            }
        });


        HBox btnContainer = new HBox(100);
        grid.add(findDream, 0, 7);
        
        btnContainer.getChildren().add(findDream);

        //vbox.getChildren().add(grid);
        //vbox.getChildren().add(btnContainer);
        
        //---------------------------------------------------------------------
        
        notDream = new Button("Not my dream - find me another!");
        notDream.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent e) {
                clearErrorMessage();
                // do the calculation
                processAction(e);
            }
        });


        HBox btnContainer2 = new HBox(100);
        notDream.setDisable(true);
        grid.add(notDream, 1, 7);
        btnContainer.getChildren().add(notDream);

        //vbox.getChildren().add(grid);
        //vbox.getChildren().add(btnContainer);
        
        //---------------------------------------------------------------------
        reset = new Button("reset");
        reset.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent e) {
                clearErrorMessage();
                myModel.reset();
            }
        });


        HBox btnContainer3 = new HBox(100);
        btnContainer3.setAlignment(Pos.CENTER);
        //reset.setDisable(true);
        grid.add(reset, 0, 8);
        btnContainer3.getChildren().add(reset);

        vbox.getChildren().add(grid);
        vbox.getChildren().add(btnContainer);
        vbox.getChildren().add(btnContainer2);
        vbox.getChildren().add(btnContainer3);
        return vbox;
    }


    // Create the status log field
    //-------------------------------------------------------------
    private MessageView createStatusLog(String initialMessage)
    {
        statusLog = new MessageView(initialMessage);

        return statusLog;
    }

    //-------------------------------------------------------------
    /*
    public void populateFields()
    {
        salesTaxRate.getItems().add("8.50");
        salesTaxRate.getItems().add("8.25");
        salesTaxRate.getItems().add("6.50");
        salesTaxRate.getItems().add("5.00");
        salesTaxRate.getItems().add("4.25");
        salesTaxRate.getItems().add("4.00");

        salesTaxRate.setValue(
                salesTaxRate.getItems().get(0));


        MinimumPrice.setText("");
}
    */
    // process events generated from our GUI components
    //-------------------------------------------------------------
    public void processAction(Event evt)
    {

        clearErrorMessage();
        // do the transfer

        //String selectedTaxRate = salesTaxRate.getValue();


        String MinimumPriceEntered = MinimumPrice.getText();
        String MaximumPriceEntered = MaximumPrice.getText();
        String MinimumAreaEntered = MinimumArea.getText();
        String MaximumAreaEntered = MaximumArea.getText();
        String MinimumBedsEntered = MinimumBeds.getText();
        String MaximumBedsEntered = MaximumBeds.getText();

        // Here, we are doing USER DATA VALIDATION
        if ((MinimumPriceEntered == null) ||(MinimumPriceEntered.length() == 0))
            MinimumPriceEntered = "0";  
        
        if ((MaximumPriceEntered == null) ||(MaximumPriceEntered.length() == 0))
            MaximumPriceEntered = "500000";       
        
        if((MinimumAreaEntered == null) ||(MinimumAreaEntered.length() == 0))
            MinimumAreaEntered = "0";
                
        if((MaximumAreaEntered == null) ||(MaximumAreaEntered.length() == 0))
            MaximumAreaEntered = "5000";
            
        if ((MinimumBedsEntered == null) ||(MinimumBedsEntered.length() == 0))
            MinimumBedsEntered ="0";
        
        if((MaximumBedsEntered == null) ||(MaximumBedsEntered.length() == 0))
        MaximumBedsEntered = "10";
        {
            try
            {
                //ChosenHome.setText(" ");
                Critreia dreamHome = new Critreia(Integer.parseInt(MinimumPriceEntered),Integer.parseInt(MaximumPriceEntered),
                Integer.parseInt(MinimumAreaEntered),Integer.parseInt(MaximumAreaEntered),
                Integer.parseInt(MinimumBedsEntered),Integer.parseInt(MaximumBedsEntered));
                
                int z = 0;
                String f = "";
                //ArrayList dreamHomeList = new ArrayList();
                String s = myModel.getHouses(dreamHome);
                String[] dreamHomeList = s.split("'");
                
                //for (int i = 0; i <= myHouseList.getHouses(dreamHome); i++){
                    
                notDream.setDisable(false);
                findDream.setDisable(true);
                //}
                //ChosenHome = String.parseString(dreamHome.getMinimunPrice());
                int x = (int)(Math.random() * dreamHomeList.length - 1) + 1;
                f = dreamHomeList[x];
                while (used.contains(x)){
                    x = (int)(Math.random() * dreamHomeList.length - 1) + 1;
                    f = dreamHomeList[x];
                    z++;
                    if(z == used.size()){
                        f = ("No more available houses ");
                        notDream.setDisable(true);
                        findDream.setDisable(false);
                        used.clear();
                        break;
                    }
                    //}else
                    //f = dreamHomeList[x];
                    System.out.println(z);
                    //used.add(z);
                    //break;
                }
                used.add(x);
                System.out.println(used.get(0));
                //f = dreamHomeList[x];
                //System.out.println(dreamHomeList.length);
                System.out.println(x);
                ChosenHome.setText(f);
                System.out.println(f);
                
                
            }
            catch (Exception ex)
            {
                displayErrorMessage
                        ("No Houses fit your Criteria");
                notDream.setDisable(true);
                findDream.setDisable(false);
            }

        }
        
    }

    /**
     * Process the data selected and entered by user.
     * Action is to pass this info on to the Loan (Model) object by
     * calling the appropriate method on the Loan object.
     */
    //----------------------------------------------------------
    private void processInvoice(String taxRate,
                                String numShirts, String numShoes, String numTies, String numPants)
    {

        Properties props = new Properties();

        props.setProperty("NumShirts", numShirts);
        props.setProperty("NumPants", numPants);
        props.setProperty("NumTies", numTies);
        props.setProperty("NumShoes", numShoes);
        props.setProperty("TaxRate", taxRate);
    }


    //---------------------------------------------------------
    public void updateState(String key, Object value)
    {

        if (key.equals("TotalPayment") == true)
        {
            String val = (String)value;
            totalPayment.setText(val);
        }
    }

    /**
     * Display error message
     */
    //----------------------------------------------------------
    public void displayErrorMessage(String message)
    {
        statusLog.displayErrorMessage(message);
    }

    /**
     * Clear error message
     */
    //----------------------------------------------------------
    public void clearErrorMessage()
    {
        statusLog.clearErrorMessage();
    }
}
